import React, { Component } from 'react';
import { HashRouter as Router, Route } from 'react-router-dom';
import ChatApp from './ChatApp';
import '../index.css';

class App extends React.Component {
    render() {
        return (
            <Router>
                <div>
                    <Route exact path="/" component={ChatApp}/>
                </div>
            </Router>
        );
    }
}

export default App;